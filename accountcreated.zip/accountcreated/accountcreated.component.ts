import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-accountcreated',
  templateUrl: './accountcreated.component.html',
  styleUrls: ['./accountcreated.component.css']
})
export class AccountcreatedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
